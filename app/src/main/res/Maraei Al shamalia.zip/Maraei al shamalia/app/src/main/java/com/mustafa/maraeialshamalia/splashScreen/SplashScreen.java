package com.mustafa.maraeialshamalia.splashScreen;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.mustafa.maraeialshamalia.R;
import com.mustafa.maraeialshamalia.introScreens.IntroActivity;

public class SplashScreen extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_splash );

        ImageView logo = findViewById(R.id.logo);

        Animation slideAnimation = AnimationUtils.loadAnimation(this, R.anim.side_slide );

        logo.startAnimation ( slideAnimation );

        Thread thread = new Thread ()
        {
            @Override
            public void run()
            {
                super.run ();

                try
                {
                    sleep ( 3000 );
                    finish ();
                    Intent startIntroActivity = new Intent (getApplicationContext (), IntroActivity.class );
                    startActivity ( startIntroActivity );

                } catch (InterruptedException e)
                {
                    e.printStackTrace ();
                }
            }
        };

        thread.start ();
    }
}