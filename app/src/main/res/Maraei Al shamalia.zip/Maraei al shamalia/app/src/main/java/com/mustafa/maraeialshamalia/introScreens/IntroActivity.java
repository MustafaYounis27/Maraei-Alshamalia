package com.mustafa.maraeialshamalia.introScreens;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.mustafa.maraeialshamalia.R;

public class IntroActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_intro );


    }
}